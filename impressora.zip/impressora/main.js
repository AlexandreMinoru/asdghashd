
const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let mainWindow;
let splash;

function createWindow() {
  splash = new BrowserWindow({
    width: 400,
    height: 300,
    frame: false,
    alwaysOnTop: true
  });

  splash.loadFile('splash.html');

  mainWindow = new BrowserWindow({
    width: 1000,
    height: 700,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'renderer.js'),
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  mainWindow.loadFile('index.html');

  setTimeout(() => {
    splash.close();
    mainWindow.show();
  }, 2000);

  ipcMain.on("print-pdf", () => {
    mainWindow.webContents.print({
      silent: false,
      printBackground: true,
      deviceName: '',
      copies: 1
    });
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
